"""
Publisher Service
"""

from sqlalchemy.orm import Session

from app.models.publisher import Publisher

from app.repositories.publisher_repository import (
    PublisherRepository,
)


class PublisherService:

    @staticmethod
    def create(
        db: Session,
        data,
    ):
        obj = Publisher(
            **data.model_dump()
        )

        return PublisherRepository.create(
            db,
            obj,
        )


    @staticmethod
    def get_by_id(
        db: Session,
        obj_id: int,
    ):
        return PublisherRepository.get_by_id(
            db,
            obj_id,
        )


    @staticmethod
    def get_all(
        db: Session,
        skip: int = 0,
        limit: int = 100,
    ):
        return PublisherRepository.get_all(
            db,
            skip=skip,
            limit=limit,
        )


    @staticmethod
    def update(
        db: Session,
        obj_id: int,
        data,
    ):
        update_data = data.model_dump(
            exclude_unset=True
        )

        return PublisherRepository.update(
            db,
            obj_id,
            update_data,
        )


    @staticmethod
    def delete(
        db: Session,
        obj_id: int,
    ):
        return PublisherRepository.delete(
            db,
            obj_id,
        )


    @staticmethod
    def exists(
        db: Session,
        obj_id: int,
    ) -> bool:
        return PublisherRepository.exists(
            db,
            obj_id,
        )
