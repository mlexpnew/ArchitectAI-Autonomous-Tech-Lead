"""
OrderItem Schemas
"""

from pydantic import BaseModel
from pydantic import ConfigDict


class OrderItemBase(BaseModel):
    order_id: int
    product_id: int
    quantity: int
    price: float


class OrderItemCreate(OrderItemBase):
    pass


class OrderItemUpdate(BaseModel):
    order_id: int | None = None
    product_id: int | None = None
    quantity: int | None = None
    price: float | None = None


class OrderItemResponse(OrderItemBase):

    id: int

    model_config = ConfigDict(
        from_attributes=True,
    )
