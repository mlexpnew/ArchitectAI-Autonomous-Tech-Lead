"""
Order Schemas
"""

from pydantic import BaseModel
from pydantic import ConfigDict


class OrderBase(BaseModel):
    customer_id: int
    total: float
    status: str


class OrderCreate(OrderBase):
    pass


class OrderUpdate(BaseModel):
    customer_id: int | None = None
    total: float | None = None
    status: str | None = None


class OrderResponse(OrderBase):

    id: int

    model_config = ConfigDict(
        from_attributes=True,
    )
