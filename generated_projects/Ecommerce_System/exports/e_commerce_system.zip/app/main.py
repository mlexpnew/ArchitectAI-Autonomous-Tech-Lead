"""
Generated FastAPI Application
"""

from fastapi import FastAPI

from app.database import Base
from app.database import engine

from app.models.customer import Customer
from app.models.product import Product
from app.models.order import Order
from app.models.orderitem import OrderItem

from app.api import customer
from app.api import product
from app.api import order
from app.api import orderitem

app = FastAPI(
    title="Generated API",
    version="1.0.0",
)

# ----------------------------------------
# Create database tables automatically
# ----------------------------------------

Base.metadata.create_all(bind=engine)

# ----------------------------------------
# Register Routers
# ----------------------------------------

app.include_router(customer.router)
app.include_router(product.router)
app.include_router(order.router)
app.include_router(orderitem.router)

@app.get("/")
def root():

    return {
        "status": "running",
        "message": "API Generated Successfully"
    }
