"""
Account Model
"""

from sqlalchemy import Boolean
from sqlalchemy import Column
from sqlalchemy import Date
from sqlalchemy import Float
from sqlalchemy import ForeignKey
from sqlalchemy import Integer
from sqlalchemy import String
from sqlalchemy import Time

from sqlalchemy.orm import relationship

from app.database import Base


class Account(Base):

    __tablename__ = "accounts"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    account_number = Column(
        String,
    )

    account_type = Column(
        String,
    )

    balance = Column(
        String,
    )

    status = Column(
        String,
    )

    created_at = Column(
        String,
    )
